import 'package:noteblock/sketches/document/document.dart';

class DocumentList {
  List<Document> documents;

  DocumentList({required this.documents});
}
