import 'package:noteblock/ads/ad.dart';

List<Ad> ads = [];
